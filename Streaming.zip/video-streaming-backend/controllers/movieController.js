const Movie = require('../models/Movie');

// Fetch the list of movies from the database
exports.getMovies = async (req, res) => {
  try {
    const movies = await Movie.find();
    res.status(200).json(movies);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get the details of a movie by its ID
exports.getMovieDetails = async (req, res) => {
  const movieId = req.params.id;

  try {
    const movie = await Movie.findById(movieId);
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    res.status(200).json(movie);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
};
