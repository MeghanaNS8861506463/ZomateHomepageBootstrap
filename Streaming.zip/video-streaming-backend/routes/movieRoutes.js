const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');

// Fetch the list of movies
router.get('/', movieController.getMovies);

// Get the details of a movie by ID
router.get('/:id', movieController.getMovieDetails);

module.exports = router;
