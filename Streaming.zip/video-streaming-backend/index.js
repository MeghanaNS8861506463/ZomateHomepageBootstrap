const express = require('express');
const mongoose = require('mongoose');
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/video-streaming-app', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('Connected to the database');
  console.log('db connected successfully');
})
.catch((error) => {
  console.error('Error connecting to the database:', error.message);
});

// Import route files
const movieRoutes = require('./routes/movieRoutes');

// Middleware
app.use(express.json());

// Routes
app.use('/api/movies', movieRoutes);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
